export interface DataAuth {
  accessToken:string,
  user:{
    email:string,
    id:number,
    name:string
  }
}
